# L'Œil du Centaure — Installation (autonome, mise à jour automatique)

Cette revue de veille est **autonome** : une fois installée, elle se met à jour
toute seule chaque matin, sans relais externe, sans serveur à gérer.

## Comment ça marche (en une phrase)
Une minuterie gratuite (GitHub) va chercher les flux des 62 sources chaque matin,
écrit le résultat dans `veille.json`, et votre page — où qu'elle soit hébergée —
lit simplement ce fichier voisin. Aucun appel externe en direct : 100 % robuste.

---

## Étape 1 — Créer le dépôt GitHub (une seule fois, ~10 min)

1. Créez un compte gratuit sur **github.com** si vous n'en avez pas.
2. Cliquez **New repository** → nommez-le par ex. `oeil-du-centaure` → **Create**.
3. Cliquez **uploading an existing file** → glissez **tout le contenu de ce dossier**
   (index.html, veille.json, le dossier `scripts/`, le dossier `.github/`).
   ⚠️ Conservez l'arborescence : `scripts/collecte.mjs` et
   `.github/workflows/veille.yml` doivent rester dans leurs dossiers.
4. **Commit changes**.

## Étape 2 — Activer la minuterie (2 min)

1. Dans le dépôt, onglet **Settings → Actions → General**.
2. Section *Workflow permissions* : cochez **Read and write permissions** → **Save**.
   (C'est ce qui autorise la minuterie à mettre à jour `veille.json`.)
3. Onglet **Actions** → si demandé, cliquez **I understand my workflows, enable them**.
4. Cliquez sur le workflow *« Veille juridique — collecte quotidienne »* →
   bouton **Run workflow** pour lancer une première collecte tout de suite.

   Après ~1 minute, `veille.json` est rempli avec les vraies actualités.

## Étape 3 — (Optionnel) activer le tri par IA

Sans ça, le tri se fait par mots-clés (correct). Pour un classement plus fin :
1. **Settings → Secrets and variables → Actions → New repository secret**.
2. Nom : `ANTHROPIC_API_KEY` — Valeur : votre clé API Anthropic → **Add secret**.

## Étape 4 — Mettre la page en ligne chez votre hébergeur (OVH, Ionos…)

Deux fichiers suffisent à votre visiteur : **index.html** et **veille.json**.
- Soit vous les déposez sur votre espace web habituel (FTP / gestionnaire de fichiers).
- Soit, plus malin : activez **GitHub Pages** (Settings → Pages → Branch: main),
  et votre Œil est en ligne gratuitement à une adresse GitHub — que vous pouvez
  relier à un sous-domaine `veille.centaure-avocats.com`.

> Si vous hébergez la page chez OVH **mais** gardez la minuterie sur GitHub, faites
> pointer la page vers le `veille.json` de GitHub : remplacez dans `index.html`
> `const VEILLE_ENDPOINT = "veille.json";` par l'URL brute du fichier sur GitHub
> (bouton « Raw » sur veille.json → copiez l'URL). La page reste autonome.

---

## Ce qui tourne tout seul ensuite
- Chaque matin à 6h (Paris), la minuterie régénère `veille.json`.
- La page affiche toujours la dernière version, sans aucune intervention.
- Si une source est momentanément indisponible, elle est ignorée proprement.

## À finaliser avant la vraie mise en ligne
- Vérifier les URLs de flux (le fichier `scripts/sources.json` les liste toutes) ;
  certaines juridictions ont des flux capricieux — testez via **Run workflow**.
- Brancher les **vraies dates** des sessions FormaConseils dans `index.html`.
- Figer les **images de une** par rubrique (photos libres).
- Faire valider la mention déontologique par Ludovic Landivaux.

## Les fichiers
```
oeil-du-centaure/
├── index.html                      ← la page (à publier)
├── veille.json                     ← les actualités (régénéré chaque matin)
├── scripts/
│   ├── collecte.mjs                ← le collecteur (tourne sur GitHub)
│   └── sources.json                ← les 62 sources
└── .github/workflows/
    └── veille.yml                  ← la minuterie quotidienne
```
